// src/pages/PainelGestao.tsx
import React from 'react';

const PainelGestao: React.FC = () => {
  return (
    <div>
      <h1>Painel de Gestão</h1>
      <p>Gerencie as agendas e configurações do sistema.</p>
    </div>
  );
};

export default PainelGestao;
