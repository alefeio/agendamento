declare module 'firebase';
